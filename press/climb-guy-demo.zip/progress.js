// Progress: run history, stats, badges, landmarks reached and unlocked skins.
// Everything is saved on this device (localStorage); there is no server.
window.Progress = (() => {
  'use strict';

  const KEY = 'tt.profile.v1';
  const MAX_RUNS = 300; // run history kept for the stats page

  // Real things you climb past, at their real heights: [m, icon, name].
  const LANDMARKS = [
    [5.5, '🦒', 'a giraffe'], [12, '🦕', 'a Brachiosaurus'], [21, '🎈', 'a hot air balloon'],
    [46, '🗽', 'the Statue of Liberty'], [108, '🦖', 'Godzilla'], [139, '🔺', 'the Great Pyramid'],
    [184, '🛸', 'the Space Needle'], [227, '🌉', 'the Golden Gate Bridge towers'], [269, '🚢', 'the Titanic (on end)'],
    [330, '🗼', 'the Eiffel Tower'], [381, '🏙️', 'the Empire State Building'], [442, '🏢', 'the Willis Tower'],
    [508, '🎋', 'Taipei 101'], [553, '🍁', 'the CN Tower'], [604, '🪨', 'Pulpit Rock (Norway)'],
    [679, '🌴', 'Merdeka 118'], [739, '💦', 'Yosemite Falls'], [828, '🌆', 'the Burj Khalifa'],
    [914, '🧗', 'El Capitan'], [979, '💧', 'Angel Falls'],
    [1085, '⛰️', 'Table Mountain'], [1250, '⚡', "Mount Thor's sheer cliff"], [1345, '🏔️', 'Ben Nevis'],
    [1444, '🌓', 'Half Dome'],
    // Far-off goals.
    [3776, '🗻', 'Mount Fuji'], [4000, '🪂', 'a skydiving jump'], [4478, '🏔️', 'the Matterhorn'],
    [5895, '🦁', 'Kilimanjaro'], [8849, '🚩', 'Mount Everest'], [10700, '✈️', 'a plane at cruising altitude'],
    [100000, '🌌', 'the edge of space'], [408000, '🛰️', 'the ISS'],
  ];

  const POWER_KINDS = ['autoGrab', 'swollen', 'freeze', 'rocket', 'breakaway', 'flood', 'ouch'];

  // Badges. Height badges are checked from your best; the rest are awarded by
  // the game (award) or at the end of a run (recordRun).
  // The main badges come only from the daily. Endless and Sprint have their
  // own (mode: ...), labeled as theirs.
  const BADGES = [
    { id: 'first', icon: '🤚', name: 'First Grip', desc: 'Catch your first ledge.' },
    { id: 'm100', icon: '🥉', name: '100 m', desc: 'Climb 100 m in a daily.', best: 100 },
    { id: 'm500', icon: '🥈', name: '500 m', desc: 'Climb 500 m in a daily.', best: 500 },
    { id: 'm1000', icon: '🥇', name: '1 km', desc: 'Climb 1,000 m in a daily.', best: 1000 },
    { id: 'm2000', icon: '🏆', name: '2 km', desc: 'Climb 2,000 m in a daily.', best: 2000 },
    { id: 'fling', icon: '💪', name: 'Fling King', desc: 'Gain 30 m in a single fling.' },
    { id: 'clutch', icon: '😅', name: 'Clutch', desc: 'Get within 1 m of the water, then climb 10 m clear.' },
    { id: 'freefall', icon: '🪂', name: 'Freefall', desc: 'Catch a ledge after falling 20 m.' },
    { id: 'purist', icon: '🧘', name: 'Purist', desc: 'Reach 300 m without popping a balloon.' },
    { id: 'marathon', icon: '⏱️', name: 'Marathon', desc: 'Survive 8 minutes in a daily.' },
    { id: 'balloons', icon: '🎈', name: 'Balloon Animal', desc: 'Pop 50 balloons in total.' },
    { id: 'rocket', icon: '🚀', name: 'Rocket Rider', desc: 'Ride 3 rockets in total.' },
    { id: 'allpowers', icon: '🌈', name: 'Tried Everything', desc: 'Pop every kind of balloon.' },
    { id: 'regular', icon: '📅', name: 'Regular', desc: 'Play 5 dailies.' },
    { id: 'dedicated', icon: '🔁', name: 'Dedicated', desc: 'Play 50 dailies.' },
    { id: 'streak7', icon: '🔥', name: 'On a Roll', desc: 'Play the daily 7 days in a row.' },
    { id: 'streak30', icon: '🗓️', name: 'Habit Forming', desc: 'Play the daily 30 days in a row.' },
    { id: 'km1', icon: '👣', name: 'First Kilometer', desc: 'Climb 1 km in total in dailies.', total: 1000 },
    { id: 'km5', icon: '🥾', name: 'Hiker', desc: 'Climb 5 km in total in dailies.', total: 5000 },
    { id: 'km10', icon: '🧗', name: 'Trailblazer', desc: 'Climb 10 km in total in dailies.', total: 10000 },
    { id: 'km25', icon: '🏔️', name: 'Mountaineer', desc: 'Climb 25 km in total in dailies.', total: 25000 },
    { id: 'km50', icon: '✈️', name: 'Cruising Altitude', desc: 'Climb 50 km in total in dailies.', total: 50000 },
    { id: 'km100', icon: '🛰️', name: 'Orbit', desc: 'Climb 100 km in total in dailies.', total: 100000 },
    { id: 'fooled', icon: '👻', name: 'Fooled', desc: 'Try to grab a ghost ledge.' },
    { id: 'birdbrain', icon: '🐦', name: 'Bird Brain', desc: 'Get knocked by birds 10 times.' },
    { id: 'splash', icon: '💦', name: 'Splash Landing', desc: 'Fall in the water below 5 m.' },
    { id: 'doubleouch', icon: '🤕', name: 'Double Ouch', desc: 'Have both hands hurt at once.' },
    // Endless
    { id: 'warmup', icon: '🌊', name: 'Warm-Up', desc: 'Play 10 Endless runs.', mode: 'endless' },
    { id: 'deepend', icon: '🤿', name: 'Deep End', desc: 'Reach 500 m in Endless.', mode: 'endless' },
    { id: 'longhaul', icon: '🌙', name: 'Long Haul', desc: 'Reach 1,000 m in Endless.', mode: 'endless' },
    { id: 'etotal1', icon: '🧭', name: 'Explorer', desc: 'Climb 1 km in total in Endless.', mode: 'endless', endlessTotal: 1000 },
    { id: 'etotal2', icon: '🗺️', name: 'Wanderer', desc: 'Climb 2.5 km in total in Endless.', mode: 'endless', endlessTotal: 2500 },
    { id: 'etotal5', icon: '🏕️', name: 'Expedition', desc: 'Climb 5 km in total in Endless.', mode: 'endless', endlessTotal: 5000 },
    { id: 'etotal10', icon: '⛰️', name: 'Summit Seeker', desc: 'Climb 10 km in total in Endless.', mode: 'endless', endlessTotal: 10000 },
    { id: 'etotal25', icon: '🎒', name: 'Trekker', desc: 'Climb 25 km in total in Endless.', mode: 'endless', endlessTotal: 25000 },
    { id: 'etotal50', icon: '🌄', name: 'Above the Clouds', desc: 'Climb 50 km in total in Endless.', mode: 'endless', endlessTotal: 50000 },
    { id: 'etotal100', icon: '🌌', name: 'Edge of Space', desc: 'Climb 100 km in total in Endless.', mode: 'endless', endlessTotal: 100000 },
    // Sprint
    { id: 'speed', icon: '⚡', name: 'Speedrun', desc: 'Reach 150 m in a Sprint.', mode: 'sprint' },
    { id: 'blur', icon: '💨', name: 'Blur', desc: 'Reach 250 m in a Sprint.', mode: 'sprint' },
    { id: 'sprinter', icon: '👟', name: 'Sprinter', desc: 'Play 10 Sprints.', mode: 'sprint' },
  ];

  // What unlocks each skin item. Missing = free. The main ones come from the
  // daily, paced for one run a day so something new arrives every few days:
  //   { total: m }   climbed in total in dailies
  //   { dailies: n } dailies played
  //   { best: m }    reached in one daily (the bragging ones)
  //   { badge: id }  (Endless and Sprint badges unlock their own items)
  const UNLOCKS = {
    body: { green: { total: 350 }, purple: { total: 1000 }, red: { badge: 'fling' }, gold: { best: 1000 }, stripes: { badge: 'dedicated' }, polka: { badge: 'balloons' } },
    hat: { party: { badge: 'first' }, bucket: { badge: 'warmup' }, cowboy: { badge: 'freefall' }, propeller: { badge: 'sprinter' }, tophat: { badge: 'clutch' }, crown: { best: 750 }, astronaut: { best: 1500 } },
    face: {
      freckles: { total: 200 }, clown: { total: 500 }, sunglasses: { total: 1700 }, roundspecs: { dailies: 3 }, scar: { badge: 'blur' },
      eyepatch: { dailies: 7 }, warpaint: { total: 4000 }, mustache: { badge: 'birdbrain' }, monocle: { badge: 'fooled' },
      disguise: { badge: 'regular' }, glasses3d: { total: 5500 }, hearts: { badge: 'streak7' }, beard: { total: 10000 },
    },
    color: { orange: { total: 100 }, purple: { total: 750 }, red: { badge: 'speed' }, black: { badge: 'splash' }, gold: { best: 500 }, rainbow: { dailies: 30 } },
    backdrop: { sunset: { total: 2200 }, night: { badge: 'longhaul' }, forest: { badge: 'purist' }, candy: { badge: 'allpowers' }, synthwave: { total: 7500 } },
    ledges: { wood: { total: 1300 }, stone: { badge: 'deepend' }, candy: { badge: 'rocket' }, neon: { dailies: 14 }, gold: { best: 2000 } },
    water: { slime: { badge: 'doubleouch' }, chocolate: { badge: 'marathon' }, lava: { total: 3000 } },
  };

  // The customize screen's slots, which list each slot draws from, and the default.
  const SLOTS = [
    { id: 'body', label: 'Body', list: 'BODIES', kind: 'body', def: 'orange' },
    { id: 'hat', label: 'Hat', list: 'HATS', kind: 'hat', def: 'none' },
    { id: 'face', label: 'Face', list: 'FACES', kind: 'face', def: 'none' },
    { id: 'leftHand', label: 'Left hand', list: 'COLORS', kind: 'color', def: 'pink' },
    { id: 'rightHand', label: 'Right hand', list: 'COLORS', kind: 'color', def: 'yellow' },
    { id: 'leftArc', label: 'Left aim arc', list: 'COLORS', kind: 'color', def: 'pink' },
    { id: 'rightArc', label: 'Right aim arc', list: 'COLORS', kind: 'color', def: 'yellow' },
    { id: 'backdrop', label: 'Backdrop', list: 'BACKDROPS', kind: 'backdrop', def: 'classic' },
    { id: 'ledges', label: 'Ledges', list: 'LEDGES', kind: 'ledges', def: 'classic' },
    { id: 'water', label: 'Water', list: 'WATERS', kind: 'water', def: 'water' },
  ];

  function blank() {
    let oldBest = 0;
    try { oldBest = JSON.parse(localStorage.getItem('climber2.best')) || 0; } catch {}
    return {
      runs: [],               // { m, ts, secs }
      best: oldBest,
      totalRuns: 0,
      totalM: 0,
      totalSecs: 0,
      popped: 0,
      kinds: {},              // balloon kinds ever popped
      birdHits: 0,
      days: {},               // 'YYYY-MM-DD' -> true
      badges: {},             // id -> timestamp earned
      landmarks: {},          // index -> timestamp first reached
      equipped: {},
      daily: {},              // 'YYYY-MM-DD' (Eastern) -> { m, n }: your one run of that day's daily
      endlessBest: 0,         // Endless and Sprint keep their own bests and counts;
      endlessRuns: 0,         // only the daily feeds the main stats
      endlessTotal: 0,        // meters climbed in Endless, all runs added up
      sprintBest: 0,          // Sprint mode (60 s) has its own best and doesn't count as a run
      sprintRuns: 0,
    };
  }

  let p = blank();
  try {
    const saved = JSON.parse(localStorage.getItem(KEY));
    if (saved) p = Object.assign(blank(), saved);
  } catch {}
  // One-time cleanup: 0 m runs are leftovers from before the history became
  // daily-only and before a missed opening catch stopped counting (a real
  // daily can't be 0 m: heights count from the ground and you catch above it).
  if (!p.cleaned0) {
    const before = p.runs.length;
    p.runs = p.runs.filter(r => r.m > 0);
    p.totalRuns = Math.max(0, p.totalRuns - (before - p.runs.length));
    for (const k of Object.keys(p.daily)) if (!(p.daily[k].m > 0)) delete p.daily[k];
    p.cleaned0 = true;
    save();
  }
  // Drop badges that no longer exist (the list was rebalanced).
  for (const id of Object.keys(p.badges)) if (!BADGES.some(b => b.id === id)) delete p.badges[id];

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(p)); } catch {}
  }

  const has = (id) => !!p.badges[id];

  function requirementMet(req) {
    if (!req) return true;
    if (req.best != null) return p.best >= req.best;
    if (req.total != null) return p.totalM >= req.total;
    if (req.dailies != null) return Object.keys(p.daily).length >= req.dailies;
    if (req.badge) return has(req.badge);
    return true;
  }

  const isUnlocked = (kind, id) => requirementMet((UNLOCKS[kind] || {})[id]);

  const MODE_NAME = { endless: 'Endless', sprint: 'Sprint' };
  const fmtM = (m) => (m >= 1000 ? `${+(m / 1000).toFixed(1)} km` : `${m} m`);

  function requirementText(kind, id) {
    const req = (UNLOCKS[kind] || {})[id];
    if (!req) return '';
    if (req.best != null) return `Reach ${fmtM(req.best)} in one run`;
    if (req.total != null) return `Climb ${fmtM(req.total)} in total`;
    if (req.dailies != null) return `Play ${req.dailies} dailies`;
    const b = BADGES.find(x => x.id === req.badge);
    return b ? `${b.mode ? `${MODE_NAME[b.mode]} badge` : 'Badge'}: ${b.name}` : '';
  }

  // Everything currently unlocked, as "kind:id" strings (to spot new unlocks).
  function unlockedSet() {
    const out = new Set();
    for (const [kind, items] of Object.entries(UNLOCKS)) {
      for (const id of Object.keys(items)) if (isUnlocked(kind, id)) out.add(`${kind}:${id}`);
    }
    return out;
  }

  function itemFor(kind, id) {
    const list = { body: Skins.BODIES, hat: Skins.HATS, face: Skins.FACES, color: Skins.COLORS, backdrop: Skins.BACKDROPS, ledges: Skins.LEDGES, water: Skins.WATERS }[kind];
    return list.find(x => x.id === id);
  }

  // How an unlock reads in a sentence ("the Crown", "the Sunset backdrop").
  const KIND_SUFFIX = { body: ' body', hat: '', face: '', color: ' hand & arc color', backdrop: ' backdrop', ledges: ' ledges', water: '' };
  function unlockLabel(key) {
    const [kind, id] = key.split(':');
    const item = itemFor(kind, id);
    return `${item ? item.name : id}${KIND_SUFFIX[kind]}`;
  }

  // The equipped skin, falling back to defaults (and away from anything locked).
  function equipped() {
    const out = {};
    for (const s of SLOTS) {
      const id = p.equipped[s.id];
      out[s.id] = id && isUnlocked(s.kind, id) ? id : s.def;
    }
    return out;
  }

  function equip(slotId, id) {
    const s = SLOTS.find(x => x.id === slotId);
    if (!s || !isUnlocked(s.kind, id)) return false;
    p.equipped[slotId] = id;
    save();
    return true;
  }

  // Award a badge now (during a run). Returns the badge if it's new.
  function award(id) {
    if (has(id)) return null;
    const b = BADGES.find(x => x.id === id);
    if (!b) return null;
    p.badges[id] = Date.now();
    save();
    return b;
  }

  // Track a popped balloon (counts toward balloon badges).
  function notePop(kind) {
    p.popped++;
    p.kinds[kind] = true;
    const got = [];
    if (kind === 'rocket') p.rockets = (p.rockets || 0) + 1;
    if (p.popped >= 50) got.push(award('balloons'));
    if (p.rockets >= 3) got.push(award('rocket'));
    if (POWER_KINDS.every(k => p.kinds[k])) got.push(award('allpowers'));
    save();
    return got.filter(Boolean);
  }

  function noteBirdHit() {
    p.birdHits++;
    save();
    return p.birdHits >= 10 ? award('birdbrain') : null;
  }

  // Mark a landmark reached; returns true the first time.
  function noteLandmark(index) {
    if (p.landmarks[index]) return false;
    p.landmarks[index] = Date.now();
    save();
    return true;
  }

  // A height reached mid-run: height badges and a live best (for unlocks).
  function noteHeight(m) {
    const got = BADGES.filter(b => b.best != null && m >= b.best).map(b => award(b.id)).filter(Boolean);
    return got;
  }

  const dayKey = (d = new Date()) => `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;

  // Save a finished run. Returns what's new: badges, unlocks, and whether it's a best.
  function recordRun({ m, secs, splash, unlockedBefore, daily }) {
    const before = unlockedBefore || unlockedSet();
    const badgesBefore = new Set(Object.keys(p.badges));
    const isBest = m > p.best;
    p.runs.push({ m, ts: Date.now(), secs: Math.round(secs) });
    if (p.runs.length > MAX_RUNS) p.runs.splice(0, p.runs.length - MAX_RUNS);
    p.best = Math.max(p.best, m);
    p.totalRuns++;
    p.totalM += m;
    p.totalSecs += secs;
    p.days[dayKey()] = true;
    for (const b of BADGES) if (b.best != null && p.best >= b.best) award(b.id);
    if (Object.keys(p.days).length >= 5) award('regular');
    if (p.totalRuns >= 50) award('dedicated');
    for (const b of BADGES) if (b.total && p.totalM >= b.total) award(b.id);
    if (splash) award('splash');
    if (daily) {
      p.daily[daily.key] = { m, n: daily.n };
      if (dailyStreak(daily.key) >= 7) award('streak7');
      if (dailyStreak(daily.key) >= 30) award('streak30');
    }
    save();
    const after = unlockedSet();
    return {
      isBest,
      newBadges: BADGES.filter(b => p.badges[b.id] && !badgesBefore.has(b.id)),
      newUnlocks: [...after].filter(k => !before.has(k)).map(unlockLabel),
    };
  }

  // Save the daily's height as you climb, so leaving mid-run (or reloading)
  // still uses up the day's one run.
  function dailyProgress(daily, m) {
    const r = p.daily[daily.key];
    if (r && !r.live) return;
    p.daily[daily.key] = { m, n: daily.n, live: true };
    save();
  }

  // Days in a row you've played the daily, counting back from today (or from
  // yesterday if today's isn't done yet, so the streak still shows).
  function dailyStreak(todayKey) {
    let k = p.daily[todayKey] ? todayKey : Daily.prevKey(todayKey);
    let n = 0;
    while (p.daily[k]) { n++; k = Daily.prevKey(k); }
    return n;
  }

  // Save a finished Sprint. Badges earned in it still count; the run history,
  // main best and totals don't change.
  function recordSprint({ m, unlockedBefore }) {
    const before = unlockedBefore || unlockedSet();
    const badgesBefore = new Set(Object.keys(p.badges));
    const isBest = m > p.sprintBest;
    p.sprintBest = Math.max(p.sprintBest, m);
    p.sprintRuns++;
    if (p.sprintRuns >= 10) award('sprinter');
    return finishSide(isBest, before, badgesBefore);
  }

  // Save a finished Endless run: its own best and count, and Endless badges.
  function recordEndless({ m, unlockedBefore }) {
    const before = unlockedBefore || unlockedSet();
    const badgesBefore = new Set(Object.keys(p.badges));
    const isBest = m > p.endlessBest;
    p.endlessBest = Math.max(p.endlessBest, m);
    p.endlessRuns++;
    p.endlessTotal = (p.endlessTotal || 0) + m;
    if (p.endlessRuns >= 10) award('warmup');
    for (const b of BADGES) if (b.endlessTotal && p.endlessTotal >= b.endlessTotal) award(b.id);
    if (m >= 500) award('deepend');
    if (m >= 1000) award('longhaul');
    return finishSide(isBest, before, badgesBefore);
  }

  function finishSide(isBest, before, badgesBefore) {
    save();
    const after = unlockedSet();
    return {
      isBest,
      newBadges: BADGES.filter(b => p.badges[b.id] && !badgesBefore.has(b.id)),
      newUnlocks: [...after].filter(k => !before.has(k)).map(unlockLabel),
    };
  }

  // The closest height-based unlock you haven't reached yet.
  // What to aim for next: the nearest unlock from total climbing (it always
  // gets closer), or else the nearest one-run height. Returns { text } or null.
  function nextUnlock() {
    let total = null, best = null;
    for (const [kind, items] of Object.entries(UNLOCKS)) {
      for (const [id, req] of Object.entries(items)) {
        const label = unlockLabel(`${kind}:${id}`);
        if (req.total != null && p.totalM < req.total && (!total || req.total < total.m)) total = { m: req.total, label };
        if (req.best != null && p.best < req.best && (!best || req.best < best.m)) best = { m: req.best, label };
      }
    }
    if (total) return { text: `Next unlock: climb ${fmtM(Math.ceil(total.m - p.totalM))} more for the ${total.label}` };
    if (best) return { text: `Next unlock: reach ${fmtM(best.m)} in one run for the ${best.label}` };
    return null;
  }

  function stats() {
    const runs = p.runs;
    const last10 = runs.slice(-10);
    return {
      best: p.best,
      totalRuns: p.totalRuns,
      totalM: p.totalM,
      totalSecs: p.totalSecs,
      avg10: last10.length ? Math.round(last10.reduce((s, r) => s + r.m, 0) / last10.length) : 0,
      popped: p.popped,
      landmarks: Object.keys(p.landmarks).length,
      badges: BADGES.filter(b => !b.mode && p.badges[b.id]).length, // the main (daily) badges
      runs,
    };
  }

  return {
    LANDMARKS, BADGES, UNLOCKS, SLOTS,
    get best() { return p.best; },
    get sprintBest() { return p.sprintBest; },
    get endlessBest() { return p.endlessBest; },
    get endlessRuns() { return p.endlessRuns; },
    get endlessTotal() { return p.endlessTotal || 0; },
    MODE_NAME,
    get sprintRuns() { return p.sprintRuns; },
    get badges() { return p.badges; },
    get landmarks() { return p.landmarks; },
    unlockedSnapshot: () => unlockedSet(),
    isUnlocked, requirementText, equipped, equip, award, notePop, noteBirdHit, noteLandmark, noteHeight,
    recordRun, recordSprint, recordEndless, nextUnlock, stats, dailyStreak,
    dailyResult: (key) => p.daily[key] || null, dailyProgress,
    // Debug: wipe all progress on this device.
    reset() { p = blank(); p.best = 0; save(); },
  };
})();
